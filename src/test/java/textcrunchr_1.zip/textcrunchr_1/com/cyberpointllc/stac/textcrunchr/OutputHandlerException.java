package textcrunchr_1.com.cyberpointllc.stac.textcrunchr;

public class OutputHandlerException extends Exception {

    public OutputHandlerException(String message) {
        super(message);
    }
}
