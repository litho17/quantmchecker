package textcrunchr_1.com.nicnilov.textmeter;

/**
 * Created as part of textmeter project
 * by Nic Nilov on 26.10.13 at 22:06
 */
public class NotImplementedException extends RuntimeException {
}
