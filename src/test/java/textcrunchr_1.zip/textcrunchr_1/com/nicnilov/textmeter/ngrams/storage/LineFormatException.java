package textcrunchr_1.com.nicnilov.textmeter.ngrams.storage;

/**
 * Created as part of textmeter project
 * by Nic Nilov on 06.10.13 at 22:25
 */
public class LineFormatException extends Exception {

    public LineFormatException(String message) {
        super(message);
    }
}
