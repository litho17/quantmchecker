package withmi_1.edu.networkcusp.record.impl;

public class StaticMDCBinderBuilder {
    public StaticMDCBinder createStaticMDCBinder() {
        return new StaticMDCBinder();
    }
}