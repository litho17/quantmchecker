package withmi_1.edu.networkcusp.record;

public class MDCBuilder {
    public MDC createMDC() {
        return new MDC();
    }
}