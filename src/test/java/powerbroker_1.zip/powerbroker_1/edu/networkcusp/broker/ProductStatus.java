package powerbroker_1.edu.networkcusp.broker;

public enum ProductStatus {
    ONLINE,
    OFFLINE
}
