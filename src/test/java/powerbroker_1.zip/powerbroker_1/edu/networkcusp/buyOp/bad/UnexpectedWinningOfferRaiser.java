package powerbroker_1.edu.networkcusp.buyOp.bad;

public class UnexpectedWinningOfferRaiser extends AuctionRaiser {
	public UnexpectedWinningOfferRaiser() { super(); }
	public UnexpectedWinningOfferRaiser(String message) { super(message); }
	public UnexpectedWinningOfferRaiser(String message, Throwable cause) { super(message, cause); }
  	public UnexpectedWinningOfferRaiser(Throwable cause) { super(cause); }
}
