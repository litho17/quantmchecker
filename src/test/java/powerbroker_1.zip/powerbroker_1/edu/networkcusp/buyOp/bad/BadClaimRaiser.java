package powerbroker_1.edu.networkcusp.buyOp.bad;


public class BadClaimRaiser extends AuctionRaiser {

	public BadClaimRaiser() { super(); }
	public BadClaimRaiser(String message) { super(message); }
	public BadClaimRaiser(String message, Throwable cause) { super(message, cause); }
  	public BadClaimRaiser(Throwable cause) { super(cause); }

}
