package powerbroker_1.edu.networkcusp.buyOp.bad;


public class RebidRaiser extends AuctionRaiser {
	
	public RebidRaiser() { super(); }
	public RebidRaiser(String message) { super(message); }
	public RebidRaiser(String message, Throwable cause) { super(message, cause); }
  	public RebidRaiser(Throwable cause) { super(cause); }

}
