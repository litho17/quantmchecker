package powerbroker_1.edu.networkcusp.logging.helpers;

public class NOPLoggerFactoryBuilder {
    public NOPLoggerFactory formNOPLoggerFactory() {
        return new NOPLoggerFactory();
    }
}